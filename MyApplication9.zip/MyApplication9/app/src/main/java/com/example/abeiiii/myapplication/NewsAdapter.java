package com.example.abeiiii.myapplication;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class NewsAdapter extends ArrayAdapter<Article> {
    public NewsAdapter(Context context, int resource, List<Article> objects) {
        super(context, resource, objects);

    }

    @Override
   /*public View getView(int position, View convertView, ViewGroup parent) {
        Article article = getItem(position);
        String s=article.getTitle();
        Log.d("poo","position is"+position+s);
        ViewHolder viewHolder;

        if(convertView == null){ //if no view to re-use then inflate a new one
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity_news2, parent, false);
            viewHolder = new ViewHolder();
            //viewHolder.image=(ImageView)convertView.findViewById(R.id.imageView);
            viewHolder.textViewtitle = (TextView) convertView.findViewById(R.id.textView);
            viewHolder.textViewauthor = (TextView) convertView.findViewById(R.id.textView2);
            viewHolder.textViewpub= (TextView) convertView.findViewById(R.id.textView3);
            convertView.setTag(viewHolder);
        } else{
            viewHolder = (ViewHolder) convertView.getTag();
        }
        //set the data from the email object
        //viewHolder.Picasso.get().load().into(iv)
        //String s1=article.getTitle();
        //String s2=article.getAuthor();
        //String s3=article.getDate();

            try {
                viewHolder.textViewtitle.setText(article.title);

                viewHolder.textViewauthor.setText(article.author);
                viewHolder.textViewpub.setText(article.date);
                Log.d("poo1", "insidetry");

            }catch (NullPointerException e)
        {
            Log.d("poo2","insidecatch");
            e.printStackTrace();
        }
        return convertView;
    }

    //View Holder to cache the views
    private static class ViewHolder{
        ImageView image;
        TextView textViewtitle;
        TextView textViewauthor;
        TextView textViewpub;
    }*/
    public View getView(int position, View convertView, ViewGroup parent) {
        final Article article = getItem(position);
        convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity_news, parent, false);
        ImageView iv=(ImageView)convertView.findViewById(R.id.imageView);
        TextView textViewSubject = (TextView) convertView.findViewById(R.id.textView);
        TextView textViewSummary = (TextView) convertView.findViewById(R.id.textView2);
        TextView textViewEmail = (TextView) convertView.findViewById(R.id.textView3);

        //set the data from the email object
        Picasso.get().load(article.getUrl2image()).into(iv);
        textViewSubject.setText(article.getTitle());
        textViewSummary.setText(article.getAuthor());
        textViewEmail.setText(article.getDate());
       // return convertView;
        /*convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("boo","hii");
               // Intent i=new Intent(NewsActivity.this,WebActivity.class);


            }
        });*/
        return convertView;
    }
   /* public void openWebPage(String url) {
        Uri webpage = Uri.parse(url);
        Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
        //if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        //}
    }*/



}

