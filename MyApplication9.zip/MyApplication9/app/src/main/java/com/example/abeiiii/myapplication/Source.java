package com.example.abeiiii.myapplication;

public class Source {
    String id;
    String name;

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    @Override
    public String toString() {
        /*return "Article{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                '}';*/
        return name +"["+id+"]";

    }
}
