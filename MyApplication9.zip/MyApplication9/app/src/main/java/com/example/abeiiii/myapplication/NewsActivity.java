package com.example.abeiiii.myapplication;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class NewsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news2);
        Intent i = getIntent();
        String title = i.getStringExtra("news");
        String newsid = i.getStringExtra("newsid");
        Log.d("tii", "got" + title);
        if (title != null) {
            Log.d("222", "news");
            //String title=extras.getString("news");
            getSupportActionBar().setTitle(title);
            StringBuilder s1=new StringBuilder("https://newsapi.org/v2/top-headlines?sources=");
            s1.append(newsid);
            s1.append("&apiKey=e9c5ee4f17a84d2dabfbf036cd81d6fa");
           //String asyurl= "\"" + s1 + "\"";
            Log.d("ccn","url"+s1);
            //String asyurl="https://newsapi.org/v2/top-headlines?sources="+newsid+"&apiKey=e9c5ee4f17a84d2dabfbf036cd81d6fa";
            new GetnewsAsync().execute(String.valueOf(s1));

        }

    }

    private class GetnewsAsync extends AsyncTask<String, Void, ArrayList<Article>> {
        @Override
        protected ArrayList<Article> doInBackground(String... params) {
            HttpURLConnection connection = null;
            ArrayList<Article> result = new ArrayList<>();
            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF8");

                    JSONObject root = new JSONObject(json);
                    JSONArray articles = root.getJSONArray("articles");

                    for (int i = 0; i < articles.length(); i++) {
                        JSONObject articleJson = articles.getJSONObject(i);
                        Article person1 = new Article();
                        person1.url2image = articleJson.getString("urlToImage");
                        person1.title = articleJson.getString("title");
                        person1.author = articleJson.getString("author");
                        person1.date = articleJson.getString("publishedAt");
                        person1.url = articleJson.getString("url");




                        Log.d("abi1", "insideasync");


                        result.add(person1);

                    }
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return result;
        }

        protected void onPostExecute(final ArrayList<Article> result) {
            if (result.size() > 0) {
                Log.d("demo", result.toString());
                ListView listView = (ListView)findViewById(R.id.lv1);
                NewsAdapter adapter = new NewsAdapter(NewsActivity.this, R.layout.activity_news, result);
                listView.setAdapter(adapter);
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Intent i=new Intent(NewsActivity.this,WebActivity.class);
                        Article article=result.get(position);
                       String su= article.getUrl();
                       i.putExtra("url",su);
                       startActivity(i);
                    }
                });


            }
        }
    }
}

